<?php get_header(); ?>

<div id="container">
	<div id="content">    
    	<?php get_template_part( 'loop', 'single' ); ?>    
    </div><!-- #content -->
</div><!-- #container -->

<?php get_footer(); ?>